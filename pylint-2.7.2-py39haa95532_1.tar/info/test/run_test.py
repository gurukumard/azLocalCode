print("import: 'pylint'")
import pylint

print("import: 'pylint.checkers'")
import pylint.checkers

print("import: 'pylint.extensions'")
import pylint.extensions

print("import: 'pylint.pyreverse'")
import pylint.pyreverse

print("import: 'pylint.reporters'")
import pylint.reporters

print("import: 'pylint.reporters.ureports'")
import pylint.reporters.ureports

